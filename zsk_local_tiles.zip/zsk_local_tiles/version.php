<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

defined('MOODLE_INTERNAL') || die();

/**
 * Version information for local_zsk_local_tiles.
 *
 * @package    local_zsk_local_tiles
 * @copyright  2025 Silvio Kuhn
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$plugin->component = 'local_zsk_local_tiles';
$plugin->version   = 2025061311;
$plugin->requires  = 2022112800; // Moodle 4.1.
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '1.0.10';
