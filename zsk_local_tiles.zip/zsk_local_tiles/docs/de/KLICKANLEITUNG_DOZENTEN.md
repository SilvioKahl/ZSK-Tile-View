# Klickanleitung für Dozenten

**Plugin:** ZSK Kachelansicht (`local_zsk_local_tiles`)

---

## Was Sie sehen

Wenn die Administration die Kachelansicht aktiviert hat, erscheinen Ihre Kurse als **Kacheln** statt als einfache Liste – mit Kursbild, Titel und Kurzbeschreibung.

Typische Orte:

- **Dashboard** (`/my/`)
- **Meine Kurse**
- ggf. **Startseite** und **Kurskatalog** (Premium)

---

## Kurs öffnen

1. Gewünschte Kachel anklicken
2. Sie gelangen in den Kurs wie gewohnt

---

## Footer-Informationen (Premium)

Am unteren Kachelrand können u. a. erscheinen:

- Lernfortschritt / Abschlussstatus
- Hinweis „noch nicht eingeschrieben“ (Katalog)
- Anzahl Kurse in einem Kursbereich

---

## Was Sie nicht einstellen

Layout, Spaltenzahl und Aktivierung liegen bei der **Website-Administration**. Bei Darstellungsproblemen den Moodle-Support kontaktieren.

Kursbild und Beschreibung pflegen Sie in den **Kurseinstellungen** des jeweiligen Kurses.
