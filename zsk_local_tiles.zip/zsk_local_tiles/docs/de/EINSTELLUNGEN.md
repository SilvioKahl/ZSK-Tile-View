# Einstellungen – ZSK Kachelansicht

**Menü:** Website-Administration → **ZSK Kacheldarstellung**

---

## Lizenz (`local_zsk_local_tiles_license`)

| Einstellung | Config-Key | Beschreibung |
|-------------|------------|--------------|
| URL des Lizenzservers | `license_server_url` | Verify-Endpunkt |
| Offline-Toleranz (Tage) | `license_grace_days` | Premium bei Serverausfall (Standard: 7) |
| Premium-Lizenzschlüssel | `license_key` | Präfix `ZSK-KA-` |
| Lizenzstatus | *(Anzeige)* | Free, Premium, Karenz, Fehler |

---

## Kachelansicht (`local_zsk_local_tiles_config`)

### Kostenlose Version

| Einstellung | Config-Key | Standard |
|-------------|------------|----------|
| Kurs-Kacheln auf dem Dashboard (Mitte) erlauben | `tiles_dashboard` | Ja |
| Kacheln anzeigen auf „Meine Kurse“ | `tiles_mycourses` | Ja |

### Premium

| Einstellung | Config-Key | Beschreibung |
|-------------|------------|--------------|
| Kurs-Kacheln auf der Startseite (Mitte) erlauben | `tiles_frontpage` | Mit Startseiten-Element „Kurs-Kacheln“ |
| Kacheln auf Kursbereichsebene | `tiles_category` | Kurskatalog + Kurssuche |
| Anzeige Kurse ohne Einschreibung | `tiles_showunenrolled` | Footer „noch nicht eingeschrieben“ |
| Kachelansicht bis Ebene | `tiles_category_maxdepth` | Tiefe im Kurskatalog (0 = unbegrenzt) |
| Platzhalter-Bild | `tiles_placeholderimage` | Für Kurse ohne Kursbild |
| Spalten pro Zeile | `tiles_grid_columns` | 1–3 |
| Bildhöhe (Pixel) | `tiles_image_height` | Standard 175 |
| Beschreibungszeilen | `tiles_desc_lines` | Standard 7 |
| Footer-Farben | `footer_color_*` | Hintergrund/Schrift für Status-Footer |

---

## Startseiten-Layout (Moodle-Core)

**Website-Administration → Startseite → Startseite-Einstellungen**

Element **Kurs-Kacheln** (Slot `8`) in `frontpageloggedin` / `frontpage` eintragen.

---

## Cron

Tägliche Lizenzprüfung: Task `verify_license_task` (ca. 03:45).
