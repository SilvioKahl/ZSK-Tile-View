# Settings – ZSK course tiles

**Menu:** Site administration → **ZSK course tiles**

---

## License (`local_zsk_local_tiles_license`)

| Setting | Config key | Description |
|---------|------------|-------------|
| License server URL | `license_server_url` | Verify endpoint |
| Offline grace (days) | `license_grace_days` | Premium when server unreachable (default: 7) |
| Premium license key | `license_key` | Prefix `ZSK-KA-` |
| License status | *(display)* | Free, Premium, Grace, error |

---

## Course tiles (`local_zsk_local_tiles_config`)

### Free tier

| Setting | Config key | Default |
|---------|------------|---------|
| Allow course tiles on Dashboard (centre) | `tiles_dashboard` | On |
| Show tiles on My courses | `tiles_mycourses` | On |

### Premium

| Setting | Config key | Description |
|---------|------------|-------------|
| Allow course tiles on site home (centre) | `tiles_frontpage` | With front page item “Course tiles” |
| Show tiles on category pages | `tiles_category` | Catalogue + search |
| Show courses without enrolment | `tiles_showunenrolled` | Footer “not yet enrolled” |
| Tile view up to level | `tiles_category_maxdepth` | Category depth (0 = unlimited) |
| Placeholder image | `tiles_placeholderimage` | For courses without image |
| Columns per row | `tiles_grid_columns` | 1–3 |
| Image height (px) | `tiles_image_height` | Default 175 |
| Description lines | `tiles_desc_lines` | Default 7 |
| Footer colours | `footer_color_*` | Background/text per status |

---

## Front page layout (Moodle core)

**Site administration → Front page → Front page settings**

Add **Course tiles** (slot `8`) to `frontpageloggedin` / `frontpage`.

---

## Cron

Daily license check: task `verify_license_task` (around 03:45).
