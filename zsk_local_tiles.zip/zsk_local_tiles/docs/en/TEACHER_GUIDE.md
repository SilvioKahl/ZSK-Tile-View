# Guide for teachers

**Plugin:** ZSK course tiles (`local_zsk_local_tiles`)

---

## What you see

When enabled by your institution, courses appear as **tiles** instead of a plain list — with course image, title, and short description.

Typical locations:

- **Dashboard** (`/my/`)
- **My courses**
- optionally **Site home** and **course catalogue** (premium)

---

## Open a course

Click the tile — you enter the course as usual.

---

## Footer information (premium)

The bottom of a tile may show:

- learning progress / completion status
- “not yet enrolled” (catalogue)
- number of courses in a category

---

## What you do not configure

Layout and activation are managed by **site administrators**. Contact Moodle support for display issues.

Course image and summary are edited in each **course settings** page.
