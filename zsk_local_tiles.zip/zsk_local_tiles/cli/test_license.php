<?php
// This file is part of Moodle - http://moodle.org/
//
// CLI license verification test for ZSK Kachelansicht.

define('CLI_SCRIPT', true);

require(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/clilib.php');

use local_zsk_local_tiles\util\license;

list($options, $unrecognized) = cli_get_params([
    'help' => false,
    'url' => '',
    'key' => '',
], ['h' => 'help']);

if ($unrecognized) {
    $unrecognized = implode(PHP_EOL . '  ', $unrecognized);
    cli_error(get_string('cliunknowoption', 'admin', $unrecognized));
}

if ($options['help']) {
    echo "Test license verification from this Moodle server.\n\n";
    echo "Usage:\n";
    echo "  php local/zsk_local_tiles/cli/test_license.php\n";
    echo "  php local/zsk_local_tiles/cli/test_license.php --url=http://host/zsk-license/api/v1/verify.php --key=ZSK-KA-....\n\n";
    echo "Uses plugin config by default; --url/--key override for one-off tests.\n";
    exit(0);
}

$serverurl = $options['url'] !== ''
    ? license::normalize_server_url($options['url'])
    : license::get_server_url();
$key = $options['key'] !== ''
    ? trim($options['key'])
    : trim((string) get_config('local_zsk_local_tiles', 'license_key'));
$siteurl = rtrim(strtolower($CFG->wwwroot), '/');

cli_heading('ZSK Kachelansicht – Lizenztest');

echo "Moodle wwwroot:  {$siteurl}\n";
echo "Verify URL:     " . ($serverurl ?: '(leer)') . "\n";
echo "Plugin:         local_zsk_local_tiles\n";
echo "Key prefix:     " . ($key !== '' ? substr($key, 0, 8) . '…' : '(leer)') . "\n\n";

if ($serverurl === '' || $key === '') {
    cli_error('URL und Schlüssel erforderlich (in Plugin-Einstellungen oder via --url / --key).');
}

$body = json_encode([
    'license_key' => $key,
    'site_url' => $siteurl,
    'plugin' => 'local_zsk_local_tiles',
]);

$curl = new curl();
$response = $curl->post($serverurl, $body, [
    'CURLOPT_HTTPHEADER' => [
        'Content-Type: application/json',
        'Accept: application/json',
    ],
    'CURLOPT_TIMEOUT' => 20,
    'CURLOPT_CONNECTTIMEOUT' => 10,
]);

$errno = $curl->get_errno();
$error = $errno ? (string) ($curl->error ?? '') : '';
if ($error === '' && $errno && function_exists('curl_strerror')) {
    $error = curl_strerror($errno);
}
$info = $curl->get_info();
$httpcode = (int) ($info['http_code'] ?? 0);

echo "HTTP status:    {$httpcode}\n";
if ($errno) {
    echo "cURL error:     [{$errno}] {$error}\n";
}
echo "Response:\n{$response}\n\n";

$data = json_decode((string) $response, true);
if (!is_array($data)) {
    cli_error('Keine JSON-Antwort – URL/Apache-Alias/Rechte prüfen.');
}

if (!empty($data['valid'])) {
    echo "Ergebnis: OK – Premium gültig bis " . userdate((int) ($data['expires'] ?? 0)) . "\n";
    exit(0);
}

$code = $data['error_code'] ?? 'unknown';
$message = $data['message'] ?? '';
cli_error("Verify fehlgeschlagen: {$code}" . ($message !== '' ? " – {$message}" : ''));
exit(1);
