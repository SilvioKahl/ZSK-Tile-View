<?php
// This file is part of Moodle - http://moodle.org/

namespace local_zsk_local_tiles\task;

use local_zsk_local_tiles\util\license;

defined('MOODLE_INTERNAL') || die();

/**
 * Re-validates the premium license against the external API.
 */
class verify_license_task extends \core\task\scheduled_task {

    /**
     * @return string
     */
    public function get_name(): string {
        return get_string('task_verify_license', 'local_zsk_local_tiles');
    }

    /**
     * @return void
     */
    public function execute(): void {
        if (empty(get_config('local_zsk_local_tiles', 'license_key'))) {
            return;
        }
        license::verify();
    }
}
