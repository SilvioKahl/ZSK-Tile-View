<?php
// This file is part of Moodle - http://moodle.org/

namespace local_zsk_local_tiles;

defined('MOODLE_INTERNAL') || die();

require_once(__DIR__ . '/../lib.php');

/**
 * Event observers for category tile rendering.
 */
class observer {

    /**
     * @param \core\event\course_category_viewed $event
     */
    public static function course_category_viewed(\core\event\course_category_viewed $event): void {
        if (!\local_zsk_local_tiles_enabled_for('category')) {
            return;
        }
        \local_zsk_local_tiles_inject_category_tiles_for_category((int) $event->objectid);
    }
}
