<?php
// This file is part of Moodle - http://moodle.org/

namespace local_zsk_local_tiles;

defined('MOODLE_INTERNAL') || die();

require_once(__DIR__ . '/../lib.php');

/**
 * Hook callbacks for tile injection.
 */
class hook_callbacks {

    /**
     * Register tile CSS in <head> before it is printed (site home / dashboard).
     *
     * @param \core\hook\output\before_standard_head_html_generation $hook
     */
    public static function register_page_styles(
        \core\hook\output\before_standard_head_html_generation $hook
    ): void {
        if (!local_zsk_local_tiles_page_needs_tile_styles()) {
            return;
        }

        $late = local_zsk_local_tiles_require_styles();
        if ($late !== '') {
            $hook->add_html($late);
        }
    }

    /**
     * @param \core\hook\output\before_standard_top_of_body_html_generation $hook
     */
    public static function inject_category_tiles(
        \core\hook\output\before_standard_top_of_body_html_generation $hook
    ): void {
        $hook->add_html(\local_zsk_local_tiles_category_tiles_bootstrap_html());
    }

    /**
     * @param \core\hook\output\before_footer_html_generation $hook
     */
    public static function inject_category_tiles_footer(
        \core\hook\output\before_footer_html_generation $hook
    ): void {
        self::inject_frontpage_coursetiles($hook);
        \local_zsk_local_tiles_inject_tiles_when_ready();
    }

    /**
     * Render course tiles in the front page centre column (Startseite nach Anmeldung).
     *
     * @param \core\hook\output\before_footer_html_generation $hook
     */
    public static function inject_frontpage_coursetiles(
        \core\hook\output\before_footer_html_generation $hook
    ): void {
        global $PAGE;

        if ($PAGE->pagetype !== 'site-index' || !\local_zsk_local_tiles\frontpage::layout_includes_coursetiles(true)) {
            return;
        }

        if (!local_zsk_local_tiles_enabled_for('frontpage')) {
            return;
        }

        $slotindex = \local_zsk_local_tiles\frontpage::get_coursetiles_slot_index();
        if ($slotindex === false) {
            return;
        }

        $hook->add_html(\local_zsk_local_tiles\frontpage::get_frontpage_layout_hide_markup());

        $html = \local_zsk_local_tiles\frontpage::render_coursetiles_section();
        if ($html !== '') {
            $html = \html_writer::div(
                $html,
                'local-zsk-tiles-frontpage-pending',
                [
                    'id' => 'local-zsk-tiles-frontpage-pending',
                    'data-layout-slot' => \local_zsk_local_tiles\frontpage::FRONTPAGECOURSETILES,
                    'data-zsk-fp-placement-pending' => '1',
                ]
            );
            $hook->add_html($html);
            if (!function_exists('local_zsk_frontpage_elements_is_enabled') || !local_zsk_frontpage_elements_is_enabled()) {
                $PAGE->requires->js_init_code(self::frontpage_position_script());
            }
        }
    }

    /**
     * @return string
     */
    protected static function frontpage_position_script(): string {
        return <<<'JS'
(function() {
    function placeFrontpageTiles() {
        var pending = document.getElementById('local-zsk-tiles-frontpage-pending');
        if (!pending) {
            return;
        }
        var section = document.getElementById('frontpage-course-tiles');
        if (!section || section.closest('#local-zsk-tiles-frontpage-pending')) {
            section = pending.querySelector('#frontpage-course-tiles');
        }
        if (!section) {
            return;
        }
        var main = document.querySelector('#region-main');
        if (!main) {
            return;
        }
        document.body.classList.add('local-zsk-tiles-frontpage-mode');
        var slot = parseInt(pending.getAttribute('data-slot-index') || '0', 10);
        var selector = '#site-news-forum, #frontpage-course-list, #frontpage-available-course-list, ' +
            '#frontpage-category-names, #frontpage-category-combo, #frontpage-upcoming-events, ' +
            '#frontpage-course-tiles';
        var existing = [];
        main.querySelectorAll(selector).forEach(function(el) {
            if (!el.closest('#local-zsk-tiles-frontpage-pending')) {
                existing.push(el);
            }
        });
        pending.removeAttribute('id');
        pending.classList.remove('local-zsk-tiles-frontpage-pending');
        var ref = existing[slot] || null;
        if (ref) {
            main.insertBefore(pending, ref);
        } else if (slot === 0) {
            main.insertBefore(pending, main.firstChild);
        } else {
            main.appendChild(pending);
        }
        document.dispatchEvent(new CustomEvent('local-zsk-tiles-tiles-rendered'));
    }
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', placeFrontpageTiles);
    } else {
        placeFrontpageTiles();
    }
})();
JS;
    }
}
