<?php
// This file is part of Moodle - http://moodle.org/

namespace local_zsk_local_tiles;

defined('MOODLE_INTERNAL') || die();

/**
 * Default dashboard block placement (centre / content region).
 */
class dashboard_block {

    /**
     * Create a block instance on the default dashboard (/my/) in the content region if missing.
     *
     * @return void
     */
    public static function ensure_default_instance(): void {
        global $CFG, $DB;

        if (!get_config('local_zsk_local_tiles', 'tiles_dashboard')) {
            return;
        }

        $systemcontext = \context_system::instance();

        if ($DB->record_exists('block_instances', [
            'blockname' => 'coursetiles',
            'parentcontextid' => $systemcontext->id,
            'pagetypepattern' => 'my-index',
        ])) {
            return;
        }

        require_once($CFG->libdir . '/blocklib.php');

        $subpagepattern = null;
        $defaultmypage = $DB->get_record('my_pages', [
            'userid' => null,
            'name' => '__default',
            'private' => 1,
        ], 'id', IGNORE_MISSING);
        if ($defaultmypage) {
            $subpagepattern = (int) $defaultmypage->id;
        }

        $page = new \moodle_page();
        $page->set_context($systemcontext);
        $page->blocks->add_blocks(
            ['content' => ['coursetiles']],
            'my-index',
            $subpagepattern
        );
    }
}
