<?php
// This file is part of Moodle - http://moodle.org/

namespace local_zsk_local_tiles\admin;

use local_zsk_local_tiles\util\license;

defined('MOODLE_INTERNAL') || die();

/**
 * Text setting available only with Premium license.
 */
class setting_premium_configtext extends \admin_setting_configtext {

    /**
     * @param string $name
     * @param string $visiblename
     * @param string $description
     * @param string $default
     * @param mixed $paramtype
     */
    public function __construct(
        string $name,
        string $visiblename,
        string $description,
        string $default,
        $paramtype = PARAM_TEXT
    ) {
        parent::__construct('local_zsk_local_tiles/' . $name, $visiblename, $description, $default, $paramtype);
    }

    /**
     * @param mixed $data
     * @return string
     */
    public function write_setting($data) {
        if (!license::is_premium()) {
            return get_string('license_error_premium_required', 'local_zsk_local_tiles');
        }
        return parent::write_setting($data);
    }
}
