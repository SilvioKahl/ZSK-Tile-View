<?php
// This file is part of Moodle - http://moodle.org/

namespace local_zsk_local_tiles\admin;

use local_zsk_local_tiles\util\license;

defined('MOODLE_INTERNAL') || die();

/**
 * Checkbox available only with Premium license.
 */
class setting_premium_checkbox extends \admin_setting_configcheckbox {

    /**
     * @param string $name
     * @param string $visiblename
     * @param string $description
     * @param int $default
     */
    public function __construct(string $name, string $visiblename, string $description, int $default = 0) {
        parent::__construct('local_zsk_local_tiles/' . $name, $visiblename, $description, $default);
    }

    /**
     * @param mixed $data
     * @return string
     */
    public function write_setting($data) {
        if (!empty($data) && !license::is_premium()) {
            return get_string('license_error_premium_required', 'local_zsk_local_tiles');
        }
        return parent::write_setting($data);
    }
}
