<?php
// This file is part of Moodle - http://moodle.org/

namespace local_zsk_local_tiles\admin;

use local_zsk_local_tiles\util\license;

defined('MOODLE_INTERNAL') || die();

/**
 * License key setting that verifies against the external API on save.
 */
class setting_license_key extends \admin_setting_configpasswordunmask {

    public function __construct() {
        parent::__construct(
            'local_zsk_local_tiles/license_key',
            get_string('license_key', 'local_zsk_local_tiles'),
            get_string('license_key_desc', 'local_zsk_local_tiles'),
            ''
        );
    }

    /**
     * @param mixed $data
     * @return string
     */
    public function write_setting($data) {
        if (empty($data)) {
            set_config('license_key', '', 'local_zsk_local_tiles');
            license::clear_license(false);
            return '';
        }

        $result = parent::write_setting($data);
        if ($result !== '') {
            return $result;
        }

        if (license::get_server_url() === '') {
            return get_string('license_error_no_server', 'local_zsk_local_tiles');
        }

        return self::verify_or_error();
    }

    /**
     * Re-verify after other license settings changed; never block the save.
     *
     * @return void
     */
    public static function notify_verify_result(): void {
        $verify = license::verify();
        if ($verify->success) {
            return;
        }

        if (!empty($verify->network_error) || ($verify->error_code ?? '') === 'bad_response') {
            \core\notification::warning(
                $verify->message !== ''
                    ? $verify->message
                    : get_string('license_warning_network_deferred', 'local_zsk_local_tiles')
            );
            return;
        }

        \core\notification::warning($verify->message);
    }

    /**
     * @return string Empty string on success or deferred verify.
     */
    public static function verify_or_error(): string {
        $verify = license::verify();
        if ($verify->success) {
            \core\notification::success($verify->message);
            return '';
        }

        if (!empty($verify->network_error) || ($verify->error_code ?? '') === 'bad_response') {
            \core\notification::warning(
                $verify->message !== ''
                    ? $verify->message
                    : get_string('license_warning_network_deferred', 'local_zsk_local_tiles')
            );
            return '';
        }

        return $verify->message !== ''
            ? $verify->message
            : get_string('license_error_network', 'local_zsk_local_tiles');
    }
}
