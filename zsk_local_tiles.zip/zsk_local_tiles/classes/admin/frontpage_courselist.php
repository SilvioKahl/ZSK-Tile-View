<?php
// This file is part of Moodle - http://moodle.org/

namespace local_zsk_local_tiles\admin;

defined('MOODLE_INTERNAL') || die();

require_once($GLOBALS['CFG']->libdir . '/adminlib.php');

/**
 * Extends the front page element dropdown with "Course tiles".
 */
class frontpage_courselist extends \admin_setting_courselist_frontpage {

    /**
     * @return bool
     */
    public function load_choices() {
        if (is_array($this->choices)) {
            return true;
        }

        parent::load_choices();

        if (class_exists(\local_zsk_frontpage_elements\admin\frontpage_courselist::class)) {
            \local_zsk_frontpage_elements\admin\frontpage_courselist::append_zsk_choices($this->choices);
            return true;
        }

        $this->choices[\local_zsk_local_tiles\frontpage::FRONTPAGECOURSETILES] = get_string(
            'frontpagecoursetiles',
            'local_zsk_local_tiles'
        );

        if (class_exists(\local_zsk_termine\frontpage::class)) {
            $this->choices[\local_zsk_termine\frontpage::FRONTPAGETERMINE] = get_string(
                'frontpagetermine',
                'local_zsk_termine'
            );
        }

        return true;
    }
}
