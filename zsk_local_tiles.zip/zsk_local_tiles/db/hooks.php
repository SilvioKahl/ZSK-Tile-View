<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

$callbacks = [
    [
        'hook' => \core\hook\output\before_standard_top_of_body_html_generation::class,
        'callback' => [\local_zsk_local_tiles\hook_callbacks::class, 'inject_category_tiles'],
    ],
    [
        'hook' => \core\hook\output\before_footer_html_generation::class,
        'callback' => [\local_zsk_local_tiles\hook_callbacks::class, 'inject_category_tiles_footer'],
    ],
];

if (class_exists(\core\hook\output\before_standard_head_html_generation::class)) {
    $callbacks[] = [
        'hook' => \core\hook\output\before_standard_head_html_generation::class,
        'callback' => [\local_zsk_local_tiles\hook_callbacks::class, 'register_page_styles'],
    ];
}
