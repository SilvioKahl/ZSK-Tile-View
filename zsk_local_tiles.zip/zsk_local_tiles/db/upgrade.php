<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

defined('MOODLE_INTERNAL') || die();

/**
 * Upgrade steps for local_zsk_local_tiles.
 *
 * @package    local_zsk_local_tiles
 * @copyright  2025 Silvio Kuhn
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

/**
 * Copy config and placeholder files from legacy local_tiles2 if present.
 *
 * @return void
 */
function local_zsk_local_tiles_migrate_legacy_plugin_data(): void {
    global $CFG;

    $configkeys = [
        'tiles_showunenrolled',
        'tiles_category',
        'tiles_category_maxdepth',
        'tiles_dashboard',
        'tiles_frontpage',
        'tiles_mycourses',
    ];

    foreach ($configkeys as $key) {
        if (get_config('local_zsk_local_tiles', $key) !== false) {
            continue;
        }
        foreach (['local_tiles2', 'local_tiles', 'local_statistics'] as $legacyplugin) {
            $value = get_config($legacyplugin, $key);
            if ($value !== false && $value !== null) {
                set_config($key, $value, 'local_zsk_local_tiles');
                break;
            }
        }
    }

    $context = context_system::instance();
    $fs = get_file_storage();
    foreach (['local_tiles2', 'local_tiles', 'local_statistics'] as $component) {
        $files = $fs->get_area_files(
            $context->id,
            $component,
            'tileplaceholder',
            0,
            'itemid, filepath, filename',
            false
        );
        foreach ($files as $file) {
            if ($file->is_directory()) {
                continue;
            }
            if ($fs->file_exists(
                $context->id,
                'local_zsk_local_tiles',
                'tileplaceholder',
                0,
                $file->get_filepath(),
                $file->get_filename()
            )) {
                continue;
            }
            $filerecord = [
                'contextid' => $context->id,
                'component' => 'local_zsk_local_tiles',
                'filearea' => 'tileplaceholder',
                'itemid' => 0,
                'filepath' => $file->get_filepath(),
                'filename' => $file->get_filename(),
            ];
            $fs->create_file_from_storedfile($filerecord, $file);
        }
    }

    require_once($CFG->dirroot . '/local/zsk_local_tiles/classes/admin/frontpage_settings.php');
    \local_zsk_local_tiles\admin\frontpage_settings::patch_admin_tree();
    require_once($CFG->dirroot . '/local/zsk_local_tiles/classes/dashboard_block.php');
    \local_zsk_local_tiles\dashboard_block::ensure_default_instance();
}

/**
 * @param int $oldversion
 * @return bool
 */
function xmldb_local_zsk_local_tiles_upgrade($oldversion) {
    if ($oldversion < 2025061300) {
        local_zsk_local_tiles_migrate_legacy_plugin_data();
        if (get_config('local_zsk_local_tiles', 'tiles_dashboard') === false) {
            set_config('tiles_dashboard', 1, 'local_zsk_local_tiles');
        }
        if (get_config('local_zsk_local_tiles', 'tiles_mycourses') === false) {
            set_config('tiles_mycourses', 1, 'local_zsk_local_tiles');
        }
        upgrade_plugin_savepoint(true, 2025061300, 'local', 'zsk_local_tiles');
    }

    if ($oldversion < 2025061301) {
        $pluginurl = get_config('local_zsk_local_tiles', 'license_server_url');
        if ($pluginurl === false || $pluginurl === '') {
            $sharedurl = get_config('local_zsk_plugins', 'license_server_url');
            if (!empty($sharedurl)) {
                set_config('license_server_url', $sharedurl, 'local_zsk_local_tiles');
            }
        }
        upgrade_plugin_savepoint(true, 2025061301, 'local', 'zsk_local_tiles');
    }

    if ($oldversion < 2025061306) {
        upgrade_plugin_savepoint(true, 2025061306, 'local', 'zsk_local_tiles');
    }

    if ($oldversion < 2025061308) {
        foreach (['license_server_url', 'license_grace_days'] as $configkey) {
            $own = get_config('local_zsk_local_tiles', $configkey);
            if ($own === false || $own === '') {
                $shared = get_config('local_zsk_plugins', $configkey);
                if ($shared !== false && $shared !== '') {
                    set_config($configkey, $shared, 'local_zsk_local_tiles');
                }
            }
        }
        upgrade_plugin_savepoint(true, 2025061308, 'local', 'zsk_local_tiles');
    }

    if ($oldversion < 2025061309) {
        if (get_config('local_zsk_local_tiles', 'license_key') === false) {
            set_config('license_key', '', 'local_zsk_local_tiles');
        }
        upgrade_plugin_savepoint(true, 2025061309, 'local', 'zsk_local_tiles');
    }

    if ($oldversion < 2025061310) {
        upgrade_plugin_savepoint(true, 2025061310, 'local', 'zsk_local_tiles');
    }

    if ($oldversion < 2025061311) {
        upgrade_plugin_savepoint(true, 2025061311, 'local', 'zsk_local_tiles');
    }

    return true;
}
