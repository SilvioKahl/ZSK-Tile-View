<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

$observers = [
    [
        'eventname' => '\core\event\course_category_viewed',
        'callback' => [\local_zsk_local_tiles\observer::class, 'course_category_viewed'],
    ],
];
