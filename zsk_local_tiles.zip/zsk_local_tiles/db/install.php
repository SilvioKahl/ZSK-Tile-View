<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

/**
 * @return bool
 */
function xmldb_local_zsk_local_tiles_install() {
    global $CFG;

    require_once($CFG->dirroot . '/local/zsk_local_tiles/lib.php');
    local_zsk_local_tiles_seed_config_defaults();

    return true;
}
