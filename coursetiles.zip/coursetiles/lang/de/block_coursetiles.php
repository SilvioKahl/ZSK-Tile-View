<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Kurs-Kacheln';
$string['coursetiles:addinstance'] = 'Block „Kurs-Kacheln“ hinzufügen';
$string['coursetiles:myaddinstance'] = 'Block „Kurs-Kacheln“ im Dashboard hinzufügen';
$string['privacy:metadata'] = 'Der Block Kurs-Kacheln zeigt nur Kursdaten aus Moodle an.';
