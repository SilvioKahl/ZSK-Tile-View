<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Course tiles';
$string['coursetiles:addinstance'] = 'Add a course tiles block';
$string['coursetiles:myaddinstance'] = 'Add a course tiles block to Dashboard';
$string['privacy:metadata'] = 'The course tiles block only displays course data from Moodle.';
