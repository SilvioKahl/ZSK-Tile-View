<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

/**
 * Add course tiles block to the dashboard centre column (content region) when enabled.
 */
function xmldb_block_coursetiles_install() {
    global $CFG;

    require_once($CFG->dirroot . '/local/zsk_local_tiles/classes/dashboard_block.php');
    \local_zsk_local_tiles\dashboard_block::ensure_default_instance();

    return true;
}
