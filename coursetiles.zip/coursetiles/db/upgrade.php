<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

/**
 * @param int $oldversion
 * @return bool
 */
function xmldb_block_coursetiles_upgrade($oldversion) {
    global $CFG;

    if ($oldversion < 2025060302) {
        if (file_exists($CFG->dirroot . '/local/tiles2/classes/dashboard_block.php')) {
            require_once($CFG->dirroot . '/local/tiles2/classes/dashboard_block.php');
            \local_tiles2\dashboard_block::ensure_default_instance();
        } else {
            require_once($CFG->dirroot . '/local/zsk_local_tiles/classes/dashboard_block.php');
            \local_zsk_local_tiles\dashboard_block::ensure_default_instance();
        }
        upgrade_plugin_savepoint(true, 2025060302, 'block', 'coursetiles');
    }

    if ($oldversion < 2025061307) {
        require_once($CFG->dirroot . '/local/zsk_local_tiles/classes/dashboard_block.php');
        \local_zsk_local_tiles\dashboard_block::ensure_default_instance();
        upgrade_plugin_savepoint(true, 2025061307, 'block', 'coursetiles');
    }

    return true;
}
