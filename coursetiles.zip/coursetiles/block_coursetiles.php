<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

/**
 * Course/category tiles as a standard Moodle block (dashboard).
 *
 * Requires local_zsk_local_tiles for data and styling.
 */
class block_coursetiles extends block_base {

    public function init(): void {
        $this->title = get_string('pluginname', 'block_coursetiles');
    }

    public function applicable_formats(): array {
        return [
            'all' => false,
            'my-index' => true,
        ];
    }

    public function instance_allow_multiple(): bool {
        return false;
    }

    public function has_config(): bool {
        return false;
    }

    public function get_content() {
        global $CFG;

        if ($this->content !== null) {
            return $this->content;
        }

        $this->content = new stdClass();
        $this->content->text = '';
        $this->content->footer = '';

        if (!isloggedin() || isguestuser()) {
            return $this->content;
        }

        require_once($CFG->dirroot . '/local/zsk_local_tiles/lib.php');
        require_once($CFG->dirroot . '/local/zsk_local_tiles/classes/output/tile_grid.php');

        if (!local_zsk_local_tiles_enabled_for('dashboard')) {
            return $this->content;
        }

        $includeunenrolled = local_zsk_local_tiles_include_unenrolled('dashboard');
        $payload = \local_zsk_local_tiles\category_tiles::build_explorable_courses_payload($includeunenrolled);

        $html = \local_zsk_local_tiles\output\tile_grid::render_items($payload['items'] ?? []);
        if ($html === '') {
            return $this->content;
        }

        $this->content->text = $html;

        global $PAGE;
        $PAGE->requires->js_init_code(
            "document.dispatchEvent(new CustomEvent('local-zsk-tiles-tiles-rendered'));"
        );

        return $this->content;
    }
}
