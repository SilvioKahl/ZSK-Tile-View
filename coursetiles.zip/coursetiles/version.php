<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

$plugin->component   = 'block_coursetiles';
$plugin->version     = 2025061307;
$plugin->requires    = 2022112800;
$plugin->maturity    = MATURITY_STABLE;
$plugin->release     = '1.1.0';
$plugin->dependencies = [
    'local_zsk_local_tiles' => 2025061300,
];
